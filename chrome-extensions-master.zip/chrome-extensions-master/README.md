# chrome-extensions
Basic Google Chrome extension tutorials to be demo'd on the 9/25/2018 coding club meeting.

Tutorial is located [here.](https://docs.google.com/document/d/1ErpSumToqOUDpf8MgIu-cUbErGwtgwO-88NPxMFfOTw/edit?usp=sharing)
